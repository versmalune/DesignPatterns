package patterns;

public interface Container {
	public Iterator getIterator();
}
