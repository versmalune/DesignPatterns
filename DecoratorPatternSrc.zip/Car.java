package decorator02;

public interface Car {
	
	public void assemble();

}
